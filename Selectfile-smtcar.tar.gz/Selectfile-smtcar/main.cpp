#include <iostream>
#include <string>
#include <boost/filesystem.hpp>
#include <boost/algorithm/string.hpp>
#include <fstream>
using namespace std;

int loadclassname(string clslist,std::vector<string> &clsname)
{
    ifstream readf(clslist);
    if(!readf.is_open())
    {
        cout<<endl<<" the clslist is not opened"<<endl;
        getchar();
    }
    string buffer;
    int clsnum=0;
    while(readf>>buffer)
    {
        clsname.push_back(buffer);
        clsnum++;
    }
    readf.close();
    cout<<endl<<"class name is loading over ! "<< endl<<"####clsnum="<<clsnum<<endl;


    return 0;
}
bool Judgmentexists(string &str ,std::vector<string> &clsname)
{
    bool flag=false;
    for (int dwi = 0; dwi < clsname.size(); ++dwi)
    {
        if(str==clsname[dwi])
        {
            flag=true;
            break;
        }
    }
    return flag;
}


int main()
{
    string imglist="/data_2/chongqing_plate/pro_chongqing.txt";
    string savelist="/data_2/chongqing_plate/pro_xs_chongqing.txt";
    string clslist="../clslist.txt";

    std::cout << "Hello, World!" << std::endl;
    std::ifstream flist(imglist);

    std::ofstream writf(savelist,ios::app);
    std::vector<string> clsname;
    loadclassname( clslist,clsname);
    std::string imgname;
    std::vector<string>seg;
    int num=0;
    while(flist >> imgname)
    {
        seg.clear();
        if(!boost::filesystem::exists(imgname))
        {
            continue;
        }
        boost::filesystem::path medipath = imgname;
        string imgfileNM = medipath.filename().string();
        boost::split(seg, imgfileNM, boost::is_any_of("_"));
        bool needimgflag=Judgmentexists(seg[0] ,clsname);
        if(needimgflag)
        {
            writf<<imgname<<endl;
            num++;
        }

    }
    writf.close();
    cout<<endl<<"it is over !"<<endl<<"num="<<num<<endl;
    return 0;
}