import caffe
import cv2
import numpy as np
import shutil
import os

label_val = ['yi-biao-pan', 'qian-fang']

def cut_imgs():
    src_root = '/media/pengshanzhen/bb42233c-19d1-4423-b161-e5256766be8e/1/argument_extern/'
    dst_root = '/media/pengshanzhen/bb42233c-19d1-4423-b161-e5256766be8e/jiakao/data/argument_extern/'
    folder_list = os.listdir(src_root)
    for folder_name in folder_list:
        folder_path = src_root + folder_name + '/'
        label_list = os.listdir(folder_path)
        for label_name in label_list:
            label_path = folder_path + label_name + '/'
            img_list = os.listdir(label_path)
            if label_name == 'delete':
                for img_name in img_list:
                    index = img_name.find('_')
                    dst_img_name  = img_name[index+1:]
                    dst_img = dst_root + folder_name + '/' + dst_img_name
                    print dst_img,'delete'
                    if(os.path.exists(dst_img)):
                        os.remove(dst_img)
            else:
                if folder_name != label_name:
                    for img_name in img_list:
                        index = img_name.find('_')
                        dst_img_name  = img_name[index+1:]
                        dst_img = dst_root + folder_name + '/' + dst_img_name
                        dst_folder = dst_root + label_name + '/'
                        result_path = dst_folder + dst_img_name
                        print dst_img,dst_folder
                        if(os.path.exists(dst_img)):
                            if(os.path.exists(result_path)):
                                os.remove(dst_img)
                            else:
                                shutil.move(dst_img, dst_folder)

def img_score():
    deploy = 'mtcnn.prototxt'
    caffemodel = 'mtcnn.caffemodel'
    net_48 = caffe.Net(deploy,caffemodel,caffe.TEST)
    caffe.set_device(0)
    caffe.set_mode_gpu()
    img_root = '/media/d/jiakao_data/save_img0819/'
    save_root = '/media/d/jiakao_data/img_low0819/'
    net_48.blobs['data'].reshape(1,3,48,48)
    labels = os.listdir(img_root)
    for label_name in labels:
        if label_name == 'other':
            continue
        print label_name
        label_folder = img_root+label_name+'/'
        save_folder = save_root + label_name + '/'
        img_list = os.listdir(label_folder)
        for img_name in img_list:
            img_path = label_folder + img_name
            srcim = cv2.imread(img_path)
            h,w,c = srcim.shape
            srcim = cv2.cvtColor(srcim, cv2.COLOR_BGR2RGB)
            scale_img = cv2.resize(srcim,(48,48))
            scale_img = (scale_img-127.5)*0.007843137
            im = np.swapaxes(scale_img, 0, 2)
            net_48.blobs['data'].data[0] = im 
            out = net_48.forward()
            pose_prob = out['prob7-4']
            max_val = -1.0
            max_index = 0
            for k in range(8):
                if(pose_prob[0,k] > max_val):
                    max_val = pose_prob[0,k]
                    max_index = k
            if max_val < 0.5:
                dst_path = save_folder + img_name
                if os.path.isfile(dst_path):
                    continue
                shutil.move(img_path, save_folder)

def show_rect():
    src_root = '/media/d/jiakao_data/ra_img/'
    file_list = os.listdir(src_root)
    for file_name in file_list:
        if(file_name.find('.jpg') == -1):
            continue
        names = file_name.split('.')
        num_str = names[0]
        text_name = num_str+'.txt'
        text_path = src_root + text_name
        with open(text_path, 'r') as f:
            rec_line = f.readline()
        rec_vals = rec_line.split()
        jpg_path  = src_root + file_name
        rec_x = int(rec_vals[0])
        rec_y = int(rec_vals[1])
        rec_w = int(rec_vals[2])
        rec_h = int(rec_vals[3])
        img = cv2.imread(jpg_path)
        h,w,c = img.shape
        rec_x = max(0, rec_x)
        rec_y = max(0, rec_y)
        rec_w = min(rec_w, w - rec_x)
        rec_h = min(rec_h, h - rec_y)
        cv2.rectangle(img,(rec_x,rec_y),(rec_x+rec_w-1, rec_y+rec_h-1), (0,0,255))
        cv2.imshow("img",img)
        cv2.waitKey(0)


def wrong_picks():
    deploy = 'dir8.prototxt'
    caffemodel = 'dir8.caffemodel'
    net_48 = caffe.Net(deploy,caffemodel,caffe.TEST)
    caffe.set_device(0)
    caffe.set_mode_gpu()
    img_file = '/home/ffh/data/face_train/direction_turn_eight/trainfile/train_gongsi_0825_new.txt'
    save_root = '/media/e/jiakao/imgs/error_img_files/result_img-gongsi0826/'
    net_48.blobs['data'].reshape(1,3,48,48)
    img_num = 0
    with open(img_file, 'r') as f:
        img_list = f.readlines()
    for img_name in img_list:
        img_vals = img_name.split()
        img_path = img_vals[0]
        for space_num in range(len(img_vals)-2):
            img_path += (' '+img_vals[space_num+1])
        img_label = label_val[int(img_vals[len(img_vals)-1])]
        srcim = cv2.imread(img_path)
        h,w,c = srcim.shape
        scale_img = cv2.resize(srcim,(48,48))
        scale_img = (scale_img-127.5)*0.007843137
        blob_img = np.swapaxes(scale_img, 0, 2)
        blob_img = np.swapaxes(blob_img, 1, 2)
        net_48.blobs['data'].data[0] = blob_img 
        out = net_48.forward()
        pose_prob = out['conv7-4']
        lr_prob = out['conv10']
        max_val = -1.0
        max_index = 0
        for k in range(8):
            if(pose_prob[0,k] > max_val):
                max_val = pose_prob[0,k]
                max_index = k
        # if label_val[max_index] == 'zuo-b':
        #     if lr_prob[0,1] > lr_prob[0,0]+0.2 :
        #         max_index = 6
        # else:
        #     if label_val[max_index] == 'you-b':
        #         if lr_prob[0,0] > lr_prob[0,1]+0.2 :
        #             max_index = 2
        if max_index != int(img_vals[len(img_vals)-1]) :
            im = cv2.cvtColor(srcim, cv2.COLOR_RGB2BGR)
            im = np.swapaxes(im, 0, 1)
            img_path_vals = img_path.split('/')
            pic_name = img_path_vals[len(img_path_vals)-1]
            dst_pic_name = label_val[max_index]+'_'+pic_name
            dst_img_path = save_root+img_label+'/'+dst_pic_name
            cv2.imwrite(dst_img_path, im)
            img_num += 1
            print 'save: ',img_num

def wrong_saveimgs():
    deploy = '/media/pengshanzhen/bb42233c-19d1-4423-b161-e5256766be8e/jiakao/forward/deploy2.prototxt'
    caffemodel = '/media/pengshanzhen/bb42233c-19d1-4423-b161-e5256766be8e/jiakao/forward/best_direction_iter_62000.caffemodel'
    net_48 = caffe.Net(deploy,caffemodel,caffe.TEST)
    caffe.set_device(0)
    caffe.set_mode_gpu()
    src_root = '/media/pengshanzhen/bb42233c-19d1-4423-b161-e5256766be8e/jiakao/data_back/save_worker_img/'
    save_root = '/media/pengshanzhen/bb42233c-19d1-4423-b161-e5256766be8e/jiakao/forward/a_save_worker_img/'
    net_48.blobs['data'].reshape(1,3,100,100)
    img_num = 0
    folder_names = os.listdir(src_root)
    for label_name in folder_names:
        if label_name == 'other':
            continue
        folder_path = src_root + label_name + '/'
        pic_list = os.listdir(folder_path)
        for pic_name in pic_list:
            img_path = folder_path + pic_name
            if(not (os.path.isfile(img_path))):
                continue
            img_label = label_name
            img_size = os.path.getsize(img_path)
            if (img_size/1024 < 1):
                continue
            #print img_path
            srcim = cv2.imread(img_path)
            h,w,c = srcim.shape
            scale_img = cv2.resize(srcim,(100,100))
            scale_img = cv2.cvtColor(scale_img, cv2.COLOR_BGR2RGB)
            scale_img = (scale_img-127.5)*0.007843137
            blob_img = np.swapaxes(scale_img, 0, 2)
            net_48.blobs['data'].data[0] = blob_img 
            out = net_48.forward()
            pose_prob = out['conv7-4_a']
            #lr_prob = out['conv10']
            max_val = -1.0
            max_index = 0
            for k in range(2):
                if(pose_prob[0,k] > max_val):
                    max_val = pose_prob[0,k]
                    max_index = k
            # if label_val[max_index] == 'zuo-b':
            #     if lr_prob[0,1] > lr_prob[0,0]+0.2 :
            #         max_index = 6
            # else:
            #     if label_val[max_index] == 'you-b':
            #         if lr_prob[0,0] > lr_prob[0,1]+0.2 :
            #             max_index = 2
            if label_val[max_index] != img_label :
                dst_pic_name = label_val[max_index]+'_'+pic_name
                #os.makedirs(str(img_label))
                dst_img_path = save_root+img_label+'/'+dst_pic_name
                cv2.imwrite(dst_img_path, srcim)
                img_num += 1
                print 'save: ',img_num

if __name__ == '__main__':
    #img_score()
    #show_rect()
    #wrong_picks()
    #wrong_saveimgs()
    cut_imgs()
