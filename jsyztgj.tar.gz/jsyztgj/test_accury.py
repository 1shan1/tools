import caffe
import cv2
import numpy as np
import shutil
import os

img_label = ['kan-dang', 'zuo-a', 'zuo-b','nei-shi-jing','yi-biao-pan','you-a', 'you-b', 'qian-fang']

lrf_label_val = [['kan-dang','you-a', 'you-b','nei-shi-jing'],[ 'zuo-a', 'zuo-b'],  ['yi-biao-pan',  'qian-fang']]
lrf_label = ['right','left','front']

left_label = ['zuo-a','zuo-b']
right_label = ['kan-dang','you-a', 'you-b','nei-shi-jing']
front_label = ['yi-biao-pan',  'qian-fang']


def net_max_index(net_out, out_name, out_len):
    pose_prob = net_out[out_name]
    max_val = -10000.0
    max_index = 0
    for k in range(out_len):
        if(pose_prob[0,k] > max_val):
            max_val = pose_prob[0,k]
            max_index = k
    return max_index

def test_single_accury():
    img_deploy = '/media/pengshanzhen/bb42233c-19d1-4423-b161-e5256766be8e/jiakao/forward/deploy2.prototxt'
    img_caffemodel = '/media/pengshanzhen/bb42233c-19d1-4423-b161-e5256766be8e/jiakao/forward/direction_iter_90000.caffemodel'
    img_net = caffe.Net(img_deploy,img_caffemodel,caffe.TEST)
    caffe.set_device(0)
    caffe.set_mode_gpu()
    src_root = './car_driver_test_copy/'
   
    img_num = 0
    correct_num = 0
    img_label= front_label
    label_num = len(img_label)
    for label_name in img_label:
        folder_path = src_root + label_name + '/'
        if not os.path.isdir(folder_path):
            continue
        img_list = os.listdir(folder_path)
        for img_name in img_list:
            img_path = folder_path + img_name
            srcim = cv2.imread(img_path)
            h,w,c = srcim.shape
            scale_img = cv2.resize(srcim,(100,100))
            scale_img = (scale_img-127.5)*0.007843137
            blob_img = np.transpose(scale_img, (2, 1, 0))
            img_net.blobs['data'].data[0] = blob_img 
            out = img_net.forward()
            k = net_max_index(out, 'conv7-4_a', len(img_label))
            img_num += 1
            
            if img_label[k] == label_name:
                correct_num += 1
            else:
                print img_label[k], label_name
    print 'accury: ',float(correct_num)/img_num


def test_accury():
    lrf_deploy = 'lrf_deploy.prototxt'
    lrf_caffemodel = 'lrf_deploy.caffemodel'
    lrf_net = caffe.Net(lrf_deploy,lrf_caffemodel,caffe.TEST)

    left_deploy = 'left_deploy.prototxt'
    left_caffemodel = 'left_deploy.caffemodel'
    left_net = caffe.Net(left_deploy,left_caffemodel,caffe.TEST)

    right_deploy = 'right_deploy.prototxt'
    right_caffemodel = 'right_deploy.caffemodel'
    right_net = caffe.Net(right_deploy,right_caffemodel,caffe.TEST)

    front_deploy = 'front_deploy.prototxt'
    front_caffemodel = 'front_deploy.caffemodel'
    front_net = caffe.Net(front_deploy,front_caffemodel,caffe.TEST)

    caffe.set_device(0)
    caffe.set_mode_gpu()

    src_root = './car_driver_test/'
    img_num = 0
    correct_num = 0

    for label_name in img_label:
        folder_path = src_root + label_name + '/'
        if not os.path.isdir(folder_path):
            continue
        img_list = os.listdir(folder_path)
        for img_name in img_list:
            img_path = folder_path + img_name
            srcim = cv2.imread(img_path)
            h,w,c = srcim.shape
            scale_img = cv2.resize(srcim,(100,100))
            scale_img = (scale_img-127.5)*0.007843137
            blob_img = np.transpose(scale_img, (2, 1, 0))
            
            lrf_net.blobs['data'].data[0] = blob_img 
            lrf_out = lrf_net.forward()
            lrf_max_index = net_max_index(lrf_out, 'conv7-4', len(lrf_label))
            img_num += 1
            if lrf_label[lrf_max_index] == 'right':
                right_net.blobs['data'].data[0] = blob_img
                right_out = right_net.forward()
                right_max_index = net_max_index(right_out, 'conv7-4_you', len(right_label))
                if right_label[right_max_index] == label_name:
                    correct_num += 1
            elif  lrf_label[lrf_max_index] == 'front':
                front_net.blobs['data'].data[0] = blob_img
                front_out = front_net.forward()
                front_max_index = net_max_index(front_out, 'conv7-4_qian', len(front_label))
                if front_label[front_max_index] == label_name:
                    correct_num += 1
            else:
                left_net.blobs['data'].data[0] = blob_img
                left_out = left_net.forward()
                left_max_index = net_max_index(left_out, 'conv10_prob', len(left_label))
                if left_label[left_max_index] == label_name:
                    correct_num += 1

    print 'accury: ',float(correct_num)/img_num

if __name__ == '__main__':
    test_single_accury()
    #test_accury()
