import os
import random

folder_list = ['save_img_0822_extern/','save_img_0823/','save_img_0826/','save_img_0902/',
    'save_img_1012/','save_img_suzhou1220/']

worker_list = ['save_worker_img/']

dir_dict = ['qian-fang','zuo-a','zuo-b','you-a','you-b','yi-biao-pan',
    'kan-dang','nei-shi-jing']

def get_lr_file():
    train_file = open('lr_train_0212.txt','w')
    test_file = open('lr_test_0212.txt','w')
    folder_root = '/media/f/jiakao/imgs/save_extern_imgs/big_extern/'
    name_list = ['argument_extern/','argument_worker/','save_img_0821_all/','save_img_0822_extern/','save_img_0823/','save_img_0826/','save_img_0902/',
    'save_img_1012/']
    file_str_list = []
    for folder_name in name_list:
        src_root = folder_root+folder_name
        label_list = os.listdir(src_root)
        for label_name in label_list:
            label_str = '0'
            if label_name == 'zuo-b':
                label_str ='0'
            elif label_name == 'you-b':
                label_str ='1'
            else:
                continue
            img_root = src_root+label_name+'/'
            img_list = os.listdir(img_root)
            for img_name in img_list:
                dst_str = img_root+img_name+' '+label_str+'\n'
                file_str_list.append(dst_str)
    random.shuffle(file_str_list)
    test_list = file_str_list[:len(file_str_list)/5]
    train_list = file_str_list[len(file_str_list)/5:]
    for txt_str in test_list:
        test_file.write(txt_str)
    for txt_str in train_list:
        train_file.write(txt_str)

def get_tain_test_file():
    train_file = open('/media/pengshanzhen/bb42233c-19d1-4423-b161-e5256766be8e/jiakao/data/1_data_without_save_worker_img/dir_train_qian_yi.txt','w')
    test_file = open('/media/pengshanzhen/bb42233c-19d1-4423-b161-e5256766be8e/jiakao/data/1_data_without_save_worker_img/dir_test_qian_yi.txt','w')
    folder_root = '/media/pengshanzhen/bb42233c-19d1-4423-b161-e5256766be8e/jiakao/data/'
    name_list = ['argument_extern/','argument_worker/','save_img_0821_all/','save_img_0822_extern/','save_img_0823/','save_img_0826/','save_img_0902/',
    'save_img_1012/','save_img_suzhou1220/']
    file_str_list = []
    for folder_name in name_list:
        src_root = folder_root+folder_name
        label_list = os.listdir(src_root)
        for label_name in label_list:
            label_str = '0'
            if label_name == 'kan-dang':
                label_str ='0'
            elif label_name == 'zuo-a':
                label_str ='1'
            elif label_name == 'zuo-b':
                label_str ='2'
            elif label_name == 'nei-shi-jing':
                label_str ='3'
            elif label_name == 'yi-biao-pan':
                label_str ='4'
            elif label_name == 'you-a':
                label_str ='5'
            elif label_name == 'you-b':
                label_str ='6'
            elif label_name == 'qian-fang':
                label_str ='7'
            else:
                continue
            img_root = src_root+label_name+'/'
            img_list = os.listdir(img_root)
            for img_name in img_list:
                if img_name.find('20171220')!= -1:
                    continue
                dst_str = img_root+img_name+' '+label_str+'\n'
                file_str_list.append(dst_str)
    random.shuffle(file_str_list)
    test_list = file_str_list[:len(file_str_list)/5]
    train_list = file_str_list[len(file_str_list)/5:]
    for txt_str in test_list:
        test_file.write(txt_str)
    for txt_str in train_list:
        train_file.write(txt_str)

def count_label_num():
    file_root = '/media/f/jiakao/imgs/save_extern_imgs/'
    dst_root = '/media/f/jiakao/imgs/save_extern_imgs/argument_extern/'
    img_num = [0,0,0,0,0,0,0,0]
    for folder_name in folder_list:
        folder_path = file_root+folder_name
        for k in range(8):
            label_name = dir_dict[k]
            dir_folder = folder_path+label_name+'/'
            img_list = os.listdir(dir_folder)
            img_num[k] += len(img_list)
    print 'img_num: ',img_num


def get_argument_file():
    file_root = '/media/f/jiakao/imgs/save_extern_imgs/big_extern/'
    dst_root = '/media/f/jiakao/imgs/save_extern_imgs/big_extern/argument_extern/'
    dst_file = open('img_argument_pair0129.txt','w')
    img_num = [0,0,0,0,0,0,0,0]
    for folder_name in folder_list:
        root_folder = file_root+folder_name
        label_list = os.listdir(root_folder)
        for label_name in label_list:
            folder_path = root_folder+label_name+'/'
            pic_list = os.listdir(folder_path)
            if label_name == 'nei-shi-jing':
                for pic_name in pic_list:
                    src_path = folder_path+pic_name
                    for k in range(5):
                        dst_path = dst_root+label_name+'/'+pic_name[:-4]+'_arg'+str(k)+'.jpg'
                        dst_file.write(src_path+' '+dst_path+'\n')
            elif label_name == 'qian-fang' or label_name == 'zuo-a' or label_name == 'you-a':
                random.shuffle(pic_list)
                for pic_name in pic_list[:len(pic_list)/2]:
                    src_path = folder_path+pic_name
                    dst_path = dst_root+label_name+'/'+pic_name[:-4]+'_arg0'+'.jpg'
                    dst_file.write(src_path+' '+dst_path+'\n')
            else:
                for pic_name in pic_list:
                    src_path = folder_path+pic_name
                    dst_path = dst_root+label_name+'/'+pic_name[:-4]+'_arg0'+'.jpg'
                    dst_file.write(src_path+' '+dst_path+'\n')


def get_worker_argument_file():
    file_root = '/media/f/jiakao/imgs/save_extern_imgs/big_extern/'
    dst_root = '/media/f/jiakao/imgs/save_extern_imgs/big_extern/argument_worker/'
    dst_file = open('img_worker_argument_pair0129.txt','w')
    img_num = [0,0,0,0,0,0,0,0]
    for folder_name in worker_list:
        root_folder = file_root+folder_name
        label_list = os.listdir(root_folder)
        for label_name in label_list:
            folder_path = root_folder+label_name+'/'
            pic_list = os.listdir(folder_path)
            if label_name == 'qian-fang' or label_name == 'zuo-a' or label_name =='zuo-b' or label_name == 'you-b':
                random.shuffle(pic_list)
                for pic_name in pic_list[:len(pic_list)/2]:
                    src_path = folder_path+pic_name
                    dst_path = dst_root+label_name+'/'+pic_name[:-4]+'_arg0'+'.jpg'
                    dst_file.write(src_path+' '+dst_path+'\n')
            else:
                for pic_name in pic_list:
                    src_path = folder_path+pic_name
                    dst_path = dst_root+label_name+'/'+pic_name[:-4]+'_arg0'+'.jpg'
                    dst_file.write(src_path+' '+dst_path+'\n')

def get_right_file():
    dst_file = open('dir_you_train_0212_nosuzhou.txt','w')
    src_file = '/media/f/jiakao/train/dir_free1_noface_slice_bigextern/muiltdata/dir_train_0212_nosuzhou.txt'
    with open(src_file,'r')as f:
        src_lines = f.readlines()
    for src_line in src_lines:
        index = src_line.rfind(' ')
        src_img_path = src_line[:index]
        label_str = src_line[index+1:index+2]
        dst_str = ''
        if label_str == '0':
            dst_str = '0'
        elif label_str == '3':
            dst_str = '1'
        elif label_str == '5':
            dst_str = '2'
        elif label_str == '6':
            dst_str = '3'
        else:
            continue
        dst_file.write(src_img_path+' '+dst_str+'\n')
    dst_file.close() 

def get_qian_file():
    dst_file = open('dir_qian_test_0212_nosuzhou.txt','w')
    src_file = '/media/f/jiakao/train/dir_free1_noface_slice_bigextern/muiltdata/dir_test_0212_nosuzhou.txt'
    with open(src_file,'r')as f:
        src_lines = f.readlines()
    for src_line in src_lines:
        index = src_line.rfind(' ')
        src_img_path = src_line[:index]
        label_str = src_line[index+1:index+2]
        dst_str = ''
        if label_str == '4':
            dst_str = '0'
        elif label_str == '7':
            dst_str = '1'
        else:
            continue
        dst_file.write(src_img_path+' '+dst_str+'\n')
    dst_file.close()


if __name__ == '__main__':
    #get_lr_file()
    get_tain_test_file()
    #get_worker_argument_file()
    #get_argument_file()
    #count_label_num()
    # get_right_file()
    # get_qian_file()
