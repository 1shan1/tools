#include <iostream>
#include <fstream>
#include "include/PersonTypes.h"
#include "include/PersonDetect.h"
#include "include/common.hpp"
#include <boost/thread.hpp>
#include <boost/filesystem.hpp>

namespace fs = boost::filesystem;

//inline int get_filenames(const std::string& dir, std::vector<std::string>& filenames)
{
    fs::path path(dir);
    if (!fs::exists(path))
    {
        return -1;
    }

    fs::directory_iterator end_iter;
    for (fs::directory_iterator iter(path); iter!=end_iter; ++iter)
    {
        if (fs::is_regular_file(iter->status()))
        {
            filenames.push_back(iter->path().string());
        }

        if (fs::is_directory(iter->status()))
        {
            get_filenames(iter->path().string(), filenames);
        }
    }
    return filenames.size();
}

//inline std::string direction_num2string(DIRECTION direction_num)
{
    std::string direction;

    switch(direction_num)
    {
        case 0:
            direction = "Up";
            break;
        case 1:
            direction = "Down";
            break;
        case 2:
            direction = "Left";
            break;
        case 3:
            direction = "Right";
            break;
        default:
            direction = "Unknown";
            break;
    }
    return direction;
}

void YoloFolderTest(std::string imagePath)
{
//    EMResult result;
    PDPtr handle;
    EMOption option;
    option.mode = GPU_MODE;
    option.gpu_id = 0;
    int count = 0;
    int totalPeopleCnt = 0;

    std::vector<std::pair<cv::Rect, det_input> > out;
    out.clear();

    std::string cfgPath = "/data/Pedestrian detection/project/PersonDetect/model";
    std::string dstPath = "/data/Pedestrian detection/project/PersonDetect/res";
    emSetOption(handle, &option);
    emCreate(cfgPath, &handle);

    std::vector<std::string> fileList;
    count = get_filenames(imagePath, fileList);
    cv::Mat new_img2;
    if(count >0)
    {
        for(auto fileItem : fileList)
        {
            int peopleCntPerImg = 0;
//            std::cout<<fileItem<<std::endl;
            cv::Mat img = cv::imread(fileItem);
            cv::Mat new_img = img.clone();
            EMResult result;
            boost::posix_time::ptime time_now,time_now1;
            boost::posix_time::millisec_posix_time_system_config::time_duration_type time_elapse;
            time_now=boost::posix_time::microsec_clock::universal_time();
            emDetect(handle, new_img, &result);
            time_now1= boost::posix_time::microsec_clock::universal_time();
            time_elapse = time_now1 - time_now;
            std::cout << "t1 time per frame: " << time_elapse.total_milliseconds() << std::endl;

            int npos = fileItem.find_last_of('.');
            std::string out_fileName = fileItem.substr(0, npos);
            int mpos = fileItem.find_last_of('/');
            out_fileName = out_fileName.substr(mpos + 1);
            std::string outFile = dstPath + "/" + out_fileName + ".jpg";

            if(result.personList.size() > 0)
            {
//                std::cout << "Person List num::" << result.personList.size() << std::endl;
//                std::cout << "Direction List num::" << result.directionList.size() << std::endl;

                for(int i=0; i<result.personList.size(); i++)
                {
                    BBox pLoc = result.personList[i];

                    peopleCntPerImg +=1;
                    totalPeopleCnt += 1;
//                    std::cout<<pLoc.x<<" "<<pLoc.y<<" "<<pLoc.width<<" "<<pLoc.height<<std::endl;
                    cv::rectangle(new_img, cv::Rect(pLoc.x,pLoc.y,pLoc.width,pLoc.height), cv::Scalar(0, 0, 255), 3, 8, 0);
//                    cv::putText(new_img, "p", cv::Point(pLoc.x-10, pLoc.y-10), cv::FONT_HERSHEY_SIMPLEX, 1.0, cv::Scalar(255, 23, 0), 5, 5);
                    cv::putText(new_img, direction_num2string(result.directionList[i].direction), cv::Point(pLoc.x-10, pLoc.y-10), cv::FONT_HERSHEY_SIMPLEX, 3.0, cv::Scalar(255, 23, 0), 5, 5);
                }
                std::cout << "per frame people count: " <<peopleCntPerImg<< std::endl;
                cv::imwrite(outFile, new_img);
                cvNamedWindow("new",CV_WINDOW_NORMAL);
                cv::imshow("new", new_img);
                if (new_img2.data)
                {
                    cvNamedWindow("old",CV_WINDOW_NORMAL);
                    cv::imshow("old", new_img2);
                }
                new_img2 = new_img.clone();
                cv::waitKey(0);
            }
            else
            {
                cv::imwrite(outFile, new_img);
            }

            //std::cout << "per frame people count: " <<every_img_num<< std::endl;
            printf("File total: %d.\n", count);
            printf("Total number of people: %d.\n", totalPeopleCnt);
        }
    }
}

void trackTest(std::string lisdir)
{
    PDPtr handle;
    EMOption option;
    option.mode = GPU_MODE;
    option.gpu_id = 0;
    int count = 0;
    int totalPeopleCnt = 0;

    std::vector<std::pair<cv::Rect, det_input> > out;
    out.clear();

    std::string cfgPath = "/data_2/peopletracking/0814/PersonDetect/model";
    std::string dstPath = "/data_2/peopletracking/0814/data/res";
    emSetOption(handle, &option);
    emCreate(cfgPath, &handle);

    //std::ifstream fin(lisdir);
    std::vector<std::string> fileList;
    std::string file;
    cv::VideoCapture capture(lisdir);
    int num = 0;
    while (true)
    {
        int peopleCntPerImg = 0;
        cv::Mat frame;
        capture >> frame;
        if (frame.empty()) break;
        cv::Mat new_img = frame.clone();
        EMResult result;
        boost::posix_time::ptime time_now,time_now1;
        boost::posix_time::millisec_posix_time_system_config::time_duration_type time_elapse;
        time_now=boost::posix_time::microsec_clock::universal_time();
        emDetect(handle, new_img, &result);
        time_now1= boost::posix_time::microsec_clock::universal_time();
        time_elapse = time_now1 - time_now;
        int fps = static_cast<int>(1000/time_elapse.total_milliseconds());
        std::cout << "t1 time per frame: " << time_elapse.total_milliseconds() << std::endl;
        std::cout<<"fps:"<<fps <<std::endl;
        //std::string spfs = 'fps:' + std::to_string(fps)
        std::string outFile = dstPath + "/" + std::to_string(num) + ".jpg";
        if(result.directionList.size() > 0)
        {
//                std::cout << "Person List num::" << result.directionList.size() << std::endl;
//                std::cout << "Direction List num::" << result.directionList.size() << std::endl;

            for(int i=0; i<result.directionList.size(); i++)
            {
                BBox pLoc = result.directionList[i].bbox;

                peopleCntPerImg +=1;
                totalPeopleCnt += 1;
//                    std::cout<<pLoc.x<<" "<<pLoc.y<<" "<<pLoc.width<<" "<<pLoc.height<<std::endl;
                cv::rectangle(new_img, cv::Rect(pLoc.x,pLoc.y,pLoc.width,pLoc.height), cv::Scalar(0, 0, 255), 3, 8, 0);
//                    cv::putText(new_img, "p", cv::Point(pLoc.x-10, pLoc.y-10), cv::FONT_HERSHEY_SIMPLEX, 1.0, cv::Scalar(255, 23, 0), 5, 5);
                cv::putText(new_img, direction_num2string(result.directionList[i].direction), cv::Point(pLoc.x-10, pLoc.y-10), cv::FONT_HERSHEY_SIMPLEX, 2.0, cv::Scalar(255, 23, 0), 5, 5);
                cv::putText(new_img, "fps:"+ std::to_string(fps),cv::Point(frame.cols-300,100), cv::FONT_HERSHEY_SIMPLEX, 2.0, cv::Scalar(255, 225, 0), 5, 5);

//                    {
//                        std::cout << "#######################trackTest##################" << std::endl;
//                        std::cout << "#i::" << i << std::endl;
//                        std::cout << "Rect X::" << pLoc.x << std::endl;
//                        std::cout << "Rect Y::" << pLoc.y << std::endl;
//                        std::cout << "Direction Value::" << result.directionList[i].direction << std::endl;
//                        std::cout << "Print Direction::" << direction_num2string(result.directionList[i].direction) << std::endl;
//                        std::cout << "#######################trackTest##################" << std::endl;
//                    }

            }
            std::cout << "per frame people count: " <<peopleCntPerImg<< std::endl;
            //cv::imwrite(outFile, new_img);
            cvNamedWindow("new",CV_WINDOW_NORMAL);
            cv::imshow("new", new_img);
            cv::waitKey(1);

//                {
//                    cvNamedWindow("new",CV_WINDOW_NORMAL);
//                    cv::imshow("new", new_img);
//                    if (new_img2.data)
//                    {
//                        cvNamedWindow("old",CV_WINDOW_NORMAL);
//                        cv::imshow("old", new_img2);
//                    }
//                    new_img2 = new_img.clone();
//                    cv::waitKey(0);
//                }
        }
        else
        {
            //cv::imwrite(outFile, new_img);
            cv::putText(new_img, "fps:"+ std::to_string(fps),cv::Point(frame.cols-300,100), cv::FONT_HERSHEY_SIMPLEX, 2.0, cv::Scalar(255, 225, 0), 5, 5);
            cvNamedWindow("new",CV_WINDOW_NORMAL);
            cv::imshow("new", new_img);
            cv::waitKey(1);
        }
        //printf("File total: %d.\n", count);
        printf("Total number of people: %d.\n", totalPeopleCnt);
        num++;


//        std::cout << "Current file::" << file << std::endl;
       // fileList.push_back(file);
        //cv::waitKey(30);
    }

    //cv::waitKey(30);
}

int main() {
    /* Version test */
    {
        std::string version = getVersion();
        std::cout << version << std::endl;
    }

//    YoloFolderTest("/data/Pedestrian detection/data/empic");
    trackTest("/data_2/peopletracking/0814/test-video/2018.8.3/192.168.100.93_01_20180803175524144_3.mp4");

    return 0;
}


########################################################################################################################################################################v######
#include <iostream>
#include "ssd.hpp"

using namespace std;

int main()
{
    std::ifstream flist("/data_2/head-detection/head_SSD/code/test.txt");
    std::string imgname;
    ssd_detect_caffe::ins();
    while(flist >>imgname)
    {
        cv::Mat img=cv::imread(imgname);
        ssd_detres res;
        ssd_detect_caffe::ins().process(img,res);
        cv::rectangle(img,cv::Rect(res.x1,res.y1,res.x2-res.x1,res.y2-res.y1),cv::Scalar(255,0,255),2,8);
        std::cout<<"label:"<<res.label<<std::endl;
        cv::imshow("img",img);
        cv::waitKey(0);
    }
    cout << "Hello World!" << endl;
    return 0;
}
########################################################################################################################################################################v######
#include <iostream>
#include "darknet.h"
#include "object_detector.h"
#include <boost/filesystem.hpp>
#include <boost/algorithm/string.hpp>

using namespace std;

int main()
{

    string imglist="/data_2/WEI_ZHANG/2018.04.23-weizhang/pro_list.txt";
    string savefolder_head="/data_2/WEI_ZHANG/2018.04.23-weizhang/un2018.04.23-weizhang_rect";
    string savelist="/data_2/WEI_ZHANG/2018.04.23-weizhang/un2018.04.23-weizhang_resultlist.txt"; // 带有车的图片路径


    char *cfgfile = "../model/yolov3-2.cfg";
    char *weightfile = "../model/yolov31_99000.weights";
    std::ifstream filelist(imglist);
    std::ofstream wrtfreslt(savelist,ios::app);

    yoloDetector::ins(0);
    std::vector<std::pair<cv::Rect, det_class> > out;

    int num=0;
    std::string img_name_full;
    while (filelist >> img_name_full)
    {

        out.clear();

        boost::filesystem::path mediapath=img_name_full;
        string imgname=mediapath.filename().string();
        string saveresult_head=savefolder_head+"/"+imgname+".rct";
        std::ofstream wrf(saveresult_head,ios::app);


        cv::Mat img = cv::imread(img_name_full);
        yoloDetector::ins(0).process(img, out);

        cv::Mat new_img1 = img.clone();
        cv::Mat new_img2 = img.clone();
        bool flag=false;
        if (out.size() > 0)
        {
            for (int i = 0; i < out.size(); i++)
            {
                if((out[i].second.score > 0.5) && ((out[i].second.id == 2) || (out[i].second.id == 5) || (out[i].second.id == 7)))
                {
                    if((out[i].first.width > 30) && (out[i].first.height > 30) && ((out[i].first.height + out[i].first.width) / 2 > 40))
                    {

                        cv::rectangle(new_img2, out[i].first, cv::Scalar(0, 0, 255), 3, 8, 0);

                        int left=max(out[i].first.x,0);
                        int top=max(out[i].first.y,0);
                        int right=min((out[i].first.x+out[i].first.width),new_img2.cols);
                        int botm=min((out[i].first.y+out[i].first.height),new_img2.rows);
                        int width_rec=right-left;
                        int height_rec=botm-top;

                        if(width_rec>0 && height_rec>0)
                        {
                            flag=true;
                            wrf<<left<<" "<<top<<" "<<width_rec<<" "<<height_rec<<endl;

                        }

                        //cv::putText(new_img2, std::to_string(out[i].second.id), cv::Point(out[i].second.x-10, out[i].second.y-10), cv::FONT_HERSHEY_SIMPLEX, 1.0, cv::Scalar(255, 23, 0), 5, 5);
                        //cv::putText(new_img2, std::to_string(out[i].second.score), cv::Point(out[i].second.x-10, out[i].second.y-10), cv::FONT_HERSHEY_SIMPLEX, 1.0, cv::Scalar(255, 23, 0), 5, 5);
                    }
                }

            }
//            cv::imshow("img", new_img2);
//            cv::waitKey(100);
        }
        if(flag)
        {
            if(num%10000==0&&num>0)
            {
                cout<<endl<<"num="<<num<<endl;
            }

            wrtfreslt<<img_name_full<<endl;
            num++;
        }
        else
        {
        ///    boost::filesystem::remove_all(saveresult_head);
        }

    }
    wrtfreslt.close();


    cout<<endl<<"############ it is over ! ############"<<endl<<"num="<<num<<endl;

    return 0;
}
########################################################################################################################################################################v#####video-interface

#include <caffe/caffe.hpp>
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <algorithm>
#include <iosfwd>
#include <memory>
#include <string>
#include <utility>
#include <vector>

#include <boost/filesystem.hpp>
#include <boost/algorithm/string.hpp>
#include <boost/format.hpp>
#include "CrowdEstimate.h"
//#include "frcnn_utils.hpp"
//#include"frcnn_param.hpp"

using namespace caffe;
using namespace  std;

int main()
{
    CrowdEstimate::ins();
    string video_path = "/data_2/crowd-predict/video/jianshezhe.MP4";
    //string imglist = "/home/pengshanzhen/test_new_people/data/B/imglist.txt";
    //string out_folder_path="/data_2/crowd-predict/out_img";
    string out_video = "/data_2/crowd-predict/video/out_video";


    //boost::filesystem::path tmppath(imglist);
    //string outfile = out_folder_path +"/"+tmppath.stem().string()+ ".jpg";
    //std::ofstream outfile(savepath,ios::app);


    //std::ifstream list(imglist);

    string mean_file = "";
    string img_path;
    cv::Mat densitymap;
    float headcount;
    cv::VideoCapture capture(video_path);
    int num = 0;
    while(true)
    {
        string outfile = out_video +"/"+std::to_string(num) + ".jpg";
        cv::Mat frame;
        capture >> frame;
        if (frame.empty()) break;
        cv::Mat new_img = frame.clone();
//        cv::Mat img=cv::imread(img_path);
//        if (img.data == NULL)
//        {
//            cout << endl << "read image error" << endl;
//            getchar();
//        }
        int64 t1 = cvGetTickCount();

        CrowdEstimate::ins().process(new_img,densitymap,headcount);
        //process(img,densitymap,headcount);
        int64 t2 = cvGetTickCount();
        cv::putText(new_img,std::to_string(headcount), cv::Point(new_img.cols-400, 100), cv::FONT_HERSHEY_SIMPLEX, 2.0, cv::Scalar(255, 23, 0), 5, 5);
        cout << "time cost:" << (t2-t1)/cvGetTickFrequency() / 1000000 << "s" << endl;
        cout << "per img people count:" << headcount <<endl;
        cv::imwrite(outfile,new_img);

        //cvNamedWindow("new",CV_WINDOW_NORMAL);
        //cv::imshow("new", img);
        //cv::waitKey(10000);




    }
    return 0;


}

###################3#3########333#######      img-interface
#include <caffe/caffe.hpp>
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <algorithm>
#include <iosfwd>
#include <memory>
#include <string>
#include <utility>
#include <vector>

#include <boost/filesystem.hpp>
#include <boost/algorithm/string.hpp>
#include <boost/format.hpp>
#include "CrowdEstimate.h"
//#include "frcnn_utils.hpp"
//#include"frcnn_param.hpp"

using namespace caffe;
using namespace  std;

int main()
{
    CrowdEstimate::ins();

    string imglist = "/home/pengshanzhen/test_new_people/data/B/imglist.txt";
    string out_folder_path="/data_2/crowd-predict/out_img";



    //boost::filesystem::path tmppath(imglist);
    //string outfile = out_folder_path +"/"+tmppath.stem().string()+ ".jpg";
    //std::ofstream outfile(savepath,ios::app);


    std::ifstream list(imglist);

    string mean_file = "";
    string img_path;
    cv::Mat densitymap;
    float headcount;
    while(list >> img_path)
    {
        boost::filesystem::path tmppath(img_path);
        string outfile = out_folder_path +"/"+tmppath.stem().string()+ ".jpg";
        cv::Mat img=cv::imread(img_path);
        if (img.data == NULL)
        {
            cout << endl << "read image error" << endl;
            getchar();
        }
        int64 t1 = cvGetTickCount();

        CrowdEstimate::ins().process(img,densitymap,headcount);
        //process(img,densitymap,headcount);
        int64 t2 = cvGetTickCount();
        cv::putText(img,std::to_string(headcount), cv::Point(img.cols-400, 100), cv::FONT_HERSHEY_SIMPLEX, 2.0, cv::Scalar(255, 23, 0), 5, 5);
        cout << "time cost:" << (t2-t1)/cvGetTickFrequency() / 1000000 << "s" << endl;
        cout << "per img people count:" << headcount <<endl;
        cv::imwrite(outfile,img);

        //cvNamedWindow("new",CV_WINDOW_NORMAL);
        //cv::imshow("new", img);
        //cv::waitKey(10000);




    }
    return 0;


}












































