import os




path = '/home/pengshanzhen/try/try/img/'
out_path = '/home/pengshanzhen/try/2'


for parent,dirnames,filenames in os.walk(path):
  #print parent
  #print dirnames
  print filenames
  for filename in filenames:
    if filename[-4:] == '.jpg':
      every_out_path = os.path.join(out_path,filename)
      print every_out_path
  
