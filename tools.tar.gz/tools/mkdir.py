import os


data_path = '/home/pengshanzhen/ss/all'
#outpath = '/data_2/char/test_picture/test_backup/'
filelist = os.listdir(data_path)


for fname in filelist:
  
  os.mkdir(fname)
