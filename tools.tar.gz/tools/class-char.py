import os,shutil
import random
import cv2

out_path = '/data_2/guolv_outlist/6-25/suzhou_finalplate_totiao/'
#img_path = '/data_2/suzhoucheguansuo/un_2018_1_plate/'
f = open('/data_2/guolv_outlist/6-25/result_suzhou.txt','r')
for line in f.readlines():
  line = line.strip()
  dirname,filename = os.path.split(line)
  #label = filename.split('_')[0]
  
  #s_label = label[:3]
  s_label = line.split('/')[5]
 
  
  #s_label = label[:3]
  mulu_path = out_path + s_label + '/' + filename
  shutil.copyfile(line,mulu_path) 
  
  
  
  
  
  
  
  
  
